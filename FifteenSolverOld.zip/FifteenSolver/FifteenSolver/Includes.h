#ifndef INCLUDES_H
#define INCLUDES_H

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

using namespace std;

#include "LinkList.h"
#include "Puzzle.h"
#include "Cascade.h"

#endif